@if($biodata <> NULL) 
    {{ $biodata['name'] }} - {{ $biodata['nik'] }}
@endif
