@if($biodata <> NULL) 
    {{ $biodata['name'] }}
@endif
