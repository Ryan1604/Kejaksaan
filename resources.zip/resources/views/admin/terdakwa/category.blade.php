@if($category <> NULL) 
    {{ $category['name'] }}
@endif
