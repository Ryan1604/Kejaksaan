@if($country <> NULL) 
    {{ $country['name'] }}
@endif