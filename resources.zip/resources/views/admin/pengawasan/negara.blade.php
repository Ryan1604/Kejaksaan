@if($negara <> NULL) 
    {{ $negara['name'] }}
@endif
