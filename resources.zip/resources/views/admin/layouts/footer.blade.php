<footer class="main-footer">
    <div class="footer-left">
        Copyright &copy; 2021 All right reserved
    </div>
</footer>
