<!-- General JS Scripts -->
<script src="{{ asset('backend/modules/jquery.min.js') }}"></script>
<script src="{{ asset('backend/modules/tooltip.js') }}"></script>
<script src="{{ asset('backend/modules/popper.js') }}"></script>
<script src="{{ asset('backend/modules/bootstrap/js/bootstrap.min.js') }}"></script>
<script src="{{ asset('backend/modules/nicescroll/jquery.nicescroll.min.js') }}"></script>

@yield('js')

<!-- Template JS File -->
<script src="{{ asset('backend/js/scripts.js') }}"></script>
