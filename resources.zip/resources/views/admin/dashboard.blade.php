@extends('admin.layouts.master')
@section('title', 'Dashboard')

@section('content')
   <!-- Main Content -->
   <div class="main-content">
    <section class="section">
      <div class="section-header">
        <h1>Dashboard</h1>
      </div>
    </section>
  </div>
@endsection


