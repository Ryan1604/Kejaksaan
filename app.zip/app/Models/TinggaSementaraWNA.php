<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TinggaSementaraWNA extends Model
{
    protected $fillable = ['name'];
}
